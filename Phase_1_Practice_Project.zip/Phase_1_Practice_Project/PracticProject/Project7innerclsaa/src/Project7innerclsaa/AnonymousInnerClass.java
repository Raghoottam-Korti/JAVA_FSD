package Project7innerclsaa;

abstract class AnonymousInnerClass {
	 public abstract void display();
}



